create view viewtest as
select `my_db`.`my_tb`.`m_id`   AS `m_id`,
       `my_db`.`my_tb`.`m_name` AS `m_name`,
       `my_db`.`my_tb`.`m_sex`  AS `m_sex`,
       `my_db`.`my_tb`.`m_ans`  AS `m_ans`
from `my_db`.`my_tb`;

