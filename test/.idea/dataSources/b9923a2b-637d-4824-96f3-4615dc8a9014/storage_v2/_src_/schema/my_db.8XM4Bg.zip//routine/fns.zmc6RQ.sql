create
    definer = root@localhost procedure fns(IN y varchar(20), IN s varchar(20))
begin
SELECT
a.ID, a.name,cOUNT(*)FROM
instructor a,teaches b,student c,takes d WHERE
a.ID = b.ID AND c.ID = d.ID
AND b.course_ID = d.course_ID AND b.year = fy
AND b.semester = s
GROUP BY a.ID;
end;

