create
    definer = root@localhost function func(years varchar(20), sem varchar(20)) returns int
begin
  declare x int;
  select count(distinct ID) from takes where year=years and semester = sem into x;
return x;
end;

