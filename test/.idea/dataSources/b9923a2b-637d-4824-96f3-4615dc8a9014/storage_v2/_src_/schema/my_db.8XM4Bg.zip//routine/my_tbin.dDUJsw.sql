create
    definer = root@localhost procedure my_tbin(IN named varchar(233), IN sexs enum ('男', '女'), IN ans int)
begin
	insert into my_tb(m_name,m_sex,m_ans) values (named,sexs,ans);
end;

