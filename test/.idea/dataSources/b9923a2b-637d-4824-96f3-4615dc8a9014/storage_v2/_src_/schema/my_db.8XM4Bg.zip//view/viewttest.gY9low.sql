create view viewttest as
select `my_db`.`myt_tb`.`m_id` AS `m_id`, `my_db`.`myt_tb`.`m_bumen` AS `m_bumen`
from `my_db`.`myt_tb`;

