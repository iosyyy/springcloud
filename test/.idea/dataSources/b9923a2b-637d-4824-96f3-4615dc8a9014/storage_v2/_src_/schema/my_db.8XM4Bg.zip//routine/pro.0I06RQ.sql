create
    definer = root@localhost procedure pro(IN years varchar(20), IN sem varchar(20))
begin

  select count(distinct ID) from takes where year=years and semester = sem;
end;

