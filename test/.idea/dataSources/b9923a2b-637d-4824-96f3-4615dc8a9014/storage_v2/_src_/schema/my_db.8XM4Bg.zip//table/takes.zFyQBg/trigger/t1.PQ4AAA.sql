create definer = root@localhost trigger t1
    before update
    on takes
    for each row
begin 
	update student set tot_cred = tot_cred-10 where ID=new.ID;
end;

